﻿Imports DukesTT_Drawing.Drw
Imports System.Threading


Public Class Form1

    Dim dm As New DrawingManager
    Public w As Integer = 80
    Dim Cols, Rows As Integer
    Dim d, r As Integer
    Public angle As Double
    Dim x As Integer
    Dim y As Integer
    Public i, j As Integer
    Dim Counter

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Cols = Width / w
        Rows = Height / w
        d = w - 10
        Draw()
    End Sub


    Sub DrawCircle()

        For i = 0 To 14
            dm.Circle(Me, w + i * w + 25, 0, w - 10)
        Next

        For j = 0 To 6
            dm.Circle(Me, 0, w + w * j + 10, w - 10)
        Next



    End Sub

    Sub Draw()

        Do While True
            Application.DoEvents()
            r = d / 2


            ' DrawCircle()

            For i = 0 To Cols - 3
                For j = 0 To Rows - 3
                    Dim x = r * Math.Cos(angle * (i + 1) - Math.PI / 2)
                    Dim y = r * Math.Sin(angle * (j + 1) - Math.PI / 2)
                    dm.Point(Me, 3, w + 25 + i * w + x + d / 2 - 4, w + 10 + j * w + y + d / 2 - 4)
                Next
            Next
            angle += 0.01
            Me.Text = angle
        Loop

    End Sub
  
End Class
