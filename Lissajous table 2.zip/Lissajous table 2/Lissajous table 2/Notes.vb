﻿Module Notes
    '  For i = 0 To Cols - 14
    '        cx = w + i * w
    '        cy = 5
    'Dim x = r * Math.Cos(angle * (i + 1) - Math.PI / 2)
    'Dim y = r * Math.Sin(angle * (i + 1) - Math.PI / 2)
    '        dm.Text(Me, i + 1, cx + 30, cy + 25)
    '        dm.Circle(Me, cx, cy, d)
    '        dm.Point(Me, 8, cx + x + offset, cy + y + offset)
    '        dm.Line(Me, Color.Black, 1, cx + x + offset + 2, 0, cx + x + offset + 2, 400)
    '    Next

    '    For j = 0 To Rows - 6
    '        cx = 5
    '        cy = w + j * w
    'Dim x = r * Math.Cos(angle * (j + 1) - Math.PI / 2)
    'Dim y = r * Math.Sin(angle * (j + 1) - Math.PI / 2)
    '        dm.Text(Me, j + 1, cx + 30, cy + 30)
    '        dm.Circle(Me, cx, cy, d)
    '        dm.Point(Me, 8, cx + x + d / 2 - 4, cy + y + d / 2 - 4)
    '        dm.Line(Me, Color.Black, 1, 0, cy + y + offset + 2, 387, cy + y + offset + 2)
    '    Next
End Module
