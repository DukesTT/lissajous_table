﻿Imports Microsoft.VisualBasic

Public Class Class1

End Class
